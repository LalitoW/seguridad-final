import socket
import os
import time
import crypto_utils
from cryptography.hazmat.primitives import serialization

# REPLACE WITH SERVER IP
SERVER_IP = '192.168.1.80' 
PORT = 65432

def run_test_sequence(sock, rsa_pub, ecc_pub):
    print("\n--- STARTING AUTOMATED TEST RUN (64, 128, 256 bytes) ---")
    sizes = [64, 128, 256]
    
    for size in sizes:
        print(f"\n[Test] Generating {size} bytes random message...")
        msg = os.urandom(size) # Random bytes
        
        # Test RSA
        packet, t = crypto_utils.rsa_hybrid_encrypt(rsa_pub, msg)
        sock.sendall(b'1' + packet)
        print(f" -> Sent via RSA-Blowfish. Encrypt Time: {t:.4f} ms")
        time.sleep(0.5) 
        
        # Test ECC
        packet, t = crypto_utils.ecc_hybrid_encrypt(ecc_pub, msg)
        sock.sendall(b'2' + packet)
        print(f" -> Sent via ECC-Blowfish. Encrypt Time: {t:.4f} ms")
        time.sleep(0.5)
        
    print("\n--- TEST RUN COMPLETE ---")

def send_sms():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            print(f"[Client] Connecting to {SERVER_IP}...")
            s.connect((SERVER_IP, PORT))
            
            print("[Client] Fetching Public Keys from Server...")
            raw_keys = s.recv(8192)
            rsa_pem, ecc_pem = raw_keys.split(b'||||')
            
            rsa_pub = serialization.load_pem_public_key(rsa_pem)
            ecc_pub = serialization.load_pem_public_key(ecc_pem)

            r_bits, r_bytes = crypto_utils.get_key_size(rsa_pub)
            e_bits, e_bytes = crypto_utils.get_key_size(ecc_pub)
            print(f"\n[METRICS] Keys Negotiated:")
            print(f" 1. RSA Key: {r_bits} bits ({r_bytes} bytes)")
            print(f" 2. ECC Key: {e_bits} bits ({e_bytes} bytes)")
            
            while True:
                print("\nOptions:")
                print("1. Send RSA-Blowfish Message (Manual)")
                print("2. Send ECC-Blowfish Message (Manual)")
                print("3. Run METRICS TEST (64/128/256 bytes)")
                print("4. End Program (Both Ends)")
                choice = input("Select: ").strip()
                
                if choice == '4':
                    print("[Client] Sending shutdown signal...")
                    s.sendall(b'SHUTDOWN')
                    break
                elif choice == '3':
                    run_test_sequence(s, rsa_pub, ecc_pub)
                    continue

                msg_text = input("Enter SMS: ")
                msg = msg_text.encode('utf-8')
                
                if choice == '1':
                    packet, t = crypto_utils.rsa_hybrid_encrypt(rsa_pub, msg)
                    print(f"RSA Encrypt Time: {t:.4f} ms")
                    s.sendall(b'1' + packet)
                elif choice == '2':
                    packet, t = crypto_utils.ecc_hybrid_encrypt(ecc_pub, msg)
                    print(f"ECC Encrypt Time: {t:.4f} ms")
                    s.sendall(b'2' + packet)
                
                # Small delay to ensure server processes before next menu
                time.sleep(0.5)

    except Exception as e:
        print(f"[Error] {e}")

if __name__ == "__main__":
    send_sms()
