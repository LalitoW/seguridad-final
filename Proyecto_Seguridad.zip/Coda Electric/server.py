import socket
import crypto_utils
from cryptography.hazmat.primitives import serialization

HOST = '0.0.0.0'
PORT = 65432

def start_server():
    print("[Server] Generating Keys...")
    rsa_priv, rsa_pub = crypto_utils.generate_rsa_keys()
    ecc_priv, ecc_pub = crypto_utils.generate_ecc_keys()

    # Get Metrics
    rsa_bits, rsa_bytes = crypto_utils.get_key_size(rsa_pub)
    ecc_bits, ecc_bytes = crypto_utils.get_key_size(ecc_pub)

    print(f" -> RSA Key: {rsa_bits} bits ({rsa_bytes} bytes)")
    print(f" -> ECC Key: {ecc_bits} bits ({ecc_bytes} bytes)")

    # Serialize to send
    rsa_pem = rsa_pub.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    ecc_pem = ecc_pub.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

    print(f"[Server] Listening on {PORT}...")

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        
        server_running = True
        while server_running:
            try:
                conn, addr = s.accept()
                with conn:
                    print(f"\n[Server] Connection from {addr}")
                    conn.sendall(rsa_pem + b'||||' + ecc_pem)
                    
                    while True: 
                        data = conn.recv(16384) 
                        if not data: break
                        
                        # Check for Shutdown Signal (Option 4)
                        if data == b'SHUTDOWN':
                            print("\n[Server] Shutdown command received from Client.")
                            server_running = False
                            break

                        mode = data[0:1]
                        payload = data[1:]
                        
                        try:
                            msg = b""
                            t = 0
                            algo_name = ""

                            if mode == b'1': # RSA Hybrid
                                algo_name = "RSA-Blowfish"
                                msg, t = crypto_utils.rsa_hybrid_decrypt(rsa_priv, payload)
                            elif mode == b'2': # ECC Hybrid
                                algo_name = "ECC-Blowfish"
                                msg, t = crypto_utils.ecc_hybrid_decrypt(ecc_priv, payload)
                            
                            # Try to decode as text, otherwise show Hex
                            content_display = ""
                            try:
                                content_display = f"TEXT: {msg.decode('utf-8')}"
                            except:
                                content_display = f"HEX: {msg.hex()[:60]}..." # Truncate if long

                            print(f"[{algo_name}] Decrypt Time: {t:.4f} ms | Size: {len(msg)} bytes")
                            print(f"   -> CONTENT: {content_display}")

                        except Exception as e:
                            print(f"Error decrypting: {e}")
                            break
            except OSError:
                break
                
    print("[Server] System Halted.")

if __name__ == "__main__":
    start_server()
