import time
import os
from cryptography.hazmat.primitives.asymmetric import rsa, ec, padding
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

# ==========================================
# METRICS & HELPERS
# ==========================================
def get_key_size(key, is_private=False):
    """Returns key size in bits and bytes."""
    if isinstance(key, rsa.RSAPrivateKey) or isinstance(key, rsa.RSAPublicKey):
        return key.key_size, key.key_size // 8
    elif isinstance(key, ec.EllipticCurvePrivateKey) or isinstance(key, ec.EllipticCurvePublicKey):
        return key.curve.key_size, key.curve.key_size // 8
    return 0, 0

def blowfish_encrypt(key, plaintext):
    """Encrypts data using Blowfish (CBC Mode) with PKCS7 padding."""
    # Blowfish block size is 64 bits (8 bytes)
    iv = os.urandom(8)
    cipher = Cipher(algorithms.Blowfish(key), modes.CBC(iv))
    encryptor = cipher.encryptor()
    
    # Pad the data to multiple of 8 bytes
    pad_len = 8 - (len(plaintext) % 8)
    padded_data = plaintext + bytes([pad_len] * pad_len)
    
    ciphertext = encryptor.update(padded_data) + encryptor.finalize()
    return iv + ciphertext # Prepend IV

def blowfish_decrypt(key, data):
    """Decrypts Blowfish data."""
    iv = data[:8]
    ciphertext = data[8:]
    
    cipher = Cipher(algorithms.Blowfish(key), modes.CBC(iv))
    decryptor = cipher.decryptor()
    padded_plaintext = decryptor.update(ciphertext) + decryptor.finalize()
    
    # Remove padding
    pad_len = padded_plaintext[-1]
    return padded_plaintext[:-pad_len]

# ==========================================
# RSA HYBRID (RSA Key Exchange + Blowfish)
# ==========================================
def generate_rsa_keys():
    priv = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    return priv, priv.public_key()

def rsa_hybrid_encrypt(public_key, message_bytes):
    start = time.perf_counter_ns()
    
    # 1. Generate a random session key for Blowfish (Variable size, using 128 bits)
    session_key = os.urandom(16) 
    
    # 2. Encrypt the Session Key using RSA
    encrypted_key = public_key.encrypt(
        session_key,
        padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None)
    )
    
    # 3. Encrypt the Message using Blowfish
    encrypted_msg = blowfish_encrypt(session_key, message_bytes)
    
    # Package: [Key Length 2 bytes][Encrypted Key][Encrypted Message]
    key_len = len(encrypted_key).to_bytes(2, 'big')
    final_packet = key_len + encrypted_key + encrypted_msg
    
    end = time.perf_counter_ns()
    return final_packet, (end - start) / 1_000_000.0 # Convert to ms

def rsa_hybrid_decrypt(private_key, packet):
    start = time.perf_counter_ns()
    
    # 1. Unpack
    k_len = int.from_bytes(packet[:2], 'big')
    encrypted_key = packet[2 : 2+k_len]
    encrypted_msg = packet[2+k_len :]
    
    # 2. Decrypt Session Key (RSA)
    session_key = private_key.decrypt(
        encrypted_key,
        padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None)
    )
    
    # 3. Decrypt Message (Blowfish)
    plaintext = blowfish_decrypt(session_key, encrypted_msg)
    
    end = time.perf_counter_ns()
    return plaintext, (end - start) / 1_000_000.0

# ==========================================
# ECC HYBRID (ECDH + Blowfish)
# ==========================================
def generate_ecc_keys():
    priv = ec.generate_private_key(ec.SECP256R1())
    return priv, priv.public_key()

def ecc_hybrid_encrypt(server_pub_key, message_bytes):
    start = time.perf_counter_ns()
    
    # 1. Generate Ephemeral Key (Client side)
    client_priv = ec.generate_private_key(ec.SECP256R1())
    client_pub = client_priv.public_key()
    
    # 2. Perform ECDH (Diffie-Hellman) to get shared secret
    shared_secret = client_priv.exchange(ec.ECDH(), server_pub_key)
    
    # 3. Derive Session Key (HKDF -> 128 bit for Blowfish)
    session_key = HKDF(
        algorithm=hashes.SHA256(), length=16, salt=None, info=b'handshake'
    ).derive(shared_secret)
    
    # 4. Encrypt Message (Blowfish)
    encrypted_msg = blowfish_encrypt(session_key, message_bytes)
    
    # Package: [Client PubKey Len 2b][Client PubKey][Encrypted Msg]
    pub_bytes = client_pub.public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
    p_len = len(pub_bytes).to_bytes(2, 'big')
    final_packet = p_len + pub_bytes + encrypted_msg
    
    end = time.perf_counter_ns()
    return final_packet, (end - start) / 1_000_000.0

def ecc_hybrid_decrypt(server_priv_key, packet):
    start = time.perf_counter_ns()
    
    # 1. Unpack
    p_len = int.from_bytes(packet[:2], 'big')
    client_pub_bytes = packet[2 : 2+p_len]
    encrypted_msg = packet[2+p_len :]
    
    # 2. Load Client Public Key
    client_pub = serialization.load_pem_public_key(client_pub_bytes)
    
    # 3. Perform ECDH (Diffie-Hellman)
    shared_secret = server_priv_key.exchange(ec.ECDH(), client_pub)
    
    # 4. Derive same Session Key
    session_key = HKDF(
        algorithm=hashes.SHA256(), length=16, salt=None, info=b'handshake'
    ).derive(shared_secret)
    
    # 5. Decrypt (Blowfish)
    plaintext = blowfish_decrypt(session_key, encrypted_msg)
    
    end = time.perf_counter_ns()
    return plaintext, (end - start) / 1_000_000.0
